# encoding: utf-8
# module cryptography.hazmat.bindings._openssl
# from /home/pyy2/.virtualenvs/pyy3.5/lib/python3.5/site-packages/cryptography/hazmat/bindings/_openssl.abi3.so
# by generator 1.145
# no doc
# no imports

# no functions
# no classes
# variables with complex values

ffi = None # (!) real value is ''

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

