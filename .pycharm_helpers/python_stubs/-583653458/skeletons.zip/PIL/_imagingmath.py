# encoding: utf-8
# module PIL._imagingmath
# from /home/pyy2/.virtualenvs/pyy3.5/lib/python3.5/site-packages/PIL/_imagingmath.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

abs_F = 140583707835888
abs_I = 140583707833424

add_F = 140583707836624
add_I = 140583707833616

and_I = 140583707834432

diff_F = 140583707837904
diff_I = 140583707834208

div_F = 140583707837776
div_I = 140583707833952

eq_F = 140583707839088
eq_I = 140583707835216

ge_F = 140583707841440
ge_I = 140583707835776

gt_F = 140583707841008
gt_I = 140583707835664

invert_I = 140583707834336

le_F = 140583707840528
le_I = 140583707835552

lshift_I = 140583707834768

lt_F = 140583707840048
lt_I = 140583707835440

max_F = 140583707838704
max_I = 140583707835104

min_F = 140583707838320
min_I = 140583707834992

mod_F = 140583707842128
mod_I = 140583707834080

mul_F = 140583707837392
mul_I = 140583707833840

neg_F = 140583707836256
neg_I = 140583707833520

ne_F = 140583707839552
ne_I = 140583707835328

or_I = 140583707834544

pow_F = 140583707842416
pow_I = 140583707841872

rshift_I = 140583707834880

sub_F = 140583707837008
sub_I = 140583707833728

xor_I = 140583707834656

# functions

def binop(*args, **kwargs): # real signature unknown
    pass

def unop(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

