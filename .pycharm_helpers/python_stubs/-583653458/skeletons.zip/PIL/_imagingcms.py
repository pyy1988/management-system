# encoding: utf-8
# module PIL._imagingcms
# from /home/pyy2/.virtualenvs/pyy3.5/lib/python3.5/site-packages/PIL/_imagingcms.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

littlecms_version = '20.90'

# functions

def buildProofTransform(*args, **kwargs): # real signature unknown
    pass

def buildTransform(*args, **kwargs): # real signature unknown
    pass

def createProfile(*args, **kwargs): # real signature unknown
    pass

def profile_frombytes(*args, **kwargs): # real signature unknown
    pass

def profile_fromstring(*args, **kwargs): # real signature unknown
    pass

def profile_open(*args, **kwargs): # real signature unknown
    pass

def profile_tobytes(*args, **kwargs): # real signature unknown
    pass

# classes

class CmsProfile(object):
    # no doc
    def is_intent_supported(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    @staticmethod # known case of __new__
    def __new__(*args, **kwargs): # real signature unknown
        """ Create and return a new object.  See help(type) for accurate signature. """
        pass

    attributes = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    blue_colorant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    blue_primary = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    chromaticity = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    chromatic_adaptation = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    clut = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    colorant_table = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    colorant_table_out = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    colorimetric_intent = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    color_space = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    connection_space = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    copyright = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    creation_date = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    device_class = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    green_colorant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    green_primary = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    header_flags = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    header_manufacturer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    header_model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    icc_measurement_condition = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    icc_version = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    icc_viewing_condition = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    intent_supported = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    is_matrix_shaper = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    luminance = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    manufacturer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    media_black_point = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    media_white_point = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    media_white_point_temperature = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    pcs = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    perceptual_rendering_intent_gamut = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    product_copyright = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    product_desc = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    product_description = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    product_manufacturer = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    product_model = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    profile_description = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    profile_id = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    red_colorant = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    red_primary = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    rendering_intent = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    saturation_rendering_intent_gamut = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    screening_description = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    target = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    technology = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    version = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    viewing_condition = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default

    xcolor_space = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default



# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

