# encoding: utf-8
# module PIL._imagingft
# from /home/pyy2/.virtualenvs/pyy3.5/lib/python3.5/site-packages/PIL/_imagingft.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc
# no imports

# Variables with simple values

freetype2_version = '2.9.1'

HAVE_RAQM = False

# functions

def getfont(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is ''

__spec__ = None # (!) real value is ''

